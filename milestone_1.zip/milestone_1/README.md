# COVID-tracing-system

database design.[waiton]
 file : https://app.diagrams.net/?title=Copy%20of%20schema.drawio&client=1#Hs1-wdc-project%2FCOVID-tracing-system%2Fmain%2Fschema.drawio

review part. [Hao]
 file : review.docx
 
research part. [jocelyn]
 file : research.docx
 
feature design part. [Kay]
 file : Feature design.docx 

sudo code of website. [Kay]
 file : project.zip 

checkpoint for milestone 1:
research: 
    add example in account manage page(change password, change phone number  etc...)
    


design:

features:
   have to add 7.venue(check-in history), 8.venue(manage account), 9.official in feature plan
   
site design:
   have to update 6.user page, 7.user my account page, 8.venue(check in history)page, 9.venue(manage account page), 10.official page in site design
   
review:
 
   
data plan:
database schema:
implementation:
